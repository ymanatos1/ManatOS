import { randomUUID } from 'node:crypto';
import type { RequestHandler } from 'express';
import createError from 'http-errors';
export const csrfTokenMiddleware: RequestHandler = (q, r, n) => {
  q.session.csrfToken ??= randomUUID();
  r.locals.csrfToken = q.session.csrfToken;
  n();
};

export const requireCsrf: RequestHandler = (q, _r, n) => {
  if (q.body?._csrf !== q.session.csrfToken) {
    n(createError(403, 'The form security token is invalid or expired.'));
    return;
  }
  n();
};
